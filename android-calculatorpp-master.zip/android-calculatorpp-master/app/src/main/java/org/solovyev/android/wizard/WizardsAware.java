package org.solovyev.android.wizard;

import javax.annotation.Nonnull;

public interface WizardsAware {

    @Nonnull
    Wizards getWizards();
}
